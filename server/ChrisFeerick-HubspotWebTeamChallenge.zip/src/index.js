import React from "react";
import ReactDOM from "react-dom";

import { AppComponent } from "app/app";

ReactDOM.render(
	<React.Fragment>
		<AppComponent />
	</React.Fragment>,
	document.getElementById("HubSpotWebTeamCodeExercise")
);
