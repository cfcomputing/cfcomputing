import React, { Component } from "react";

import { media } from "../data/data.json";

export class FilterableContent extends Component {
	constructor(props) {
		super(props);
		this.state = {
			genreFilterOpen: false,
			yearFilterOpen: false,
			filteredMedia: [...media],
			typeFilter: "",
			searchVal: "",
			genre: [],
			years: []
		};

		// I pre-processed the data as it feels closer to what I would typically off load to a compile time process if this is indeed static
		// if not then I would process wherever made the most sense server or client depending on if it would change and could be done once and cached etc.
		this.genres = [
			{ label: "Action", value: "action" },
			{ label: "Adventure", value: "adventure" },
			{ label: "Animation", value: "animation" },
			{ label: "Biography", value: "biography" },
			{ label: "Classics", value: "classics" },
			{ label: "Comedy", value: "comedy" },
			{ label: "Crime", value: "crime" },
			{ label: "Detective", value: "detective" },
			{ label: "Dragons", value: "dragons" },
			{ label: "Drama", value: "drama" },
			{ label: "Fantasy", value: "fantasy" },
			{ label: "Food & Drink", value: "food & drink" },
			{ label: "History", value: "history" },
			{ label: "Horror", value: "horror" },
			{ label: "Memoir", value: "memoir" },
			{ label: "Mystery", value: "mystery" },
			{ label: "Politics", value: "politics" },
			{ label: "Science Fiction", value: "sci-fi" },
			{ label: "Science", value: "science" },
			{ label: "Thriller", value: "thriller" },
			{ label: "War", value: "war" },
			{ label: "Western", value: "western" }
		];

		this.years = [
			"1870",
			"1892",
			"1895",
			"1963",
			"1971",
			"1973",
			"1974",
			"1977",
			"1981",
			"1984",
			"1987",
			"1991",
			"1993",
			"1994",
			"1996",
			"1998",
			"2000",
			"2002",
			"2003",
			"2005",
			"2008",
			"2010",
			"2013",
			"2015"
		];
	}

	openGenreFilter = () => {
		this.setState(
			{
				genreFilterOpen: true
			},
			() => {
				document.removeEventListener("click", this.closeGenreFilter); // no effect hopefully but just in case never want to register twice
				document.addEventListener("click", this.closeGenreFilter);
			}
		);
	};

	closeGenreFilter = event => {
		// if the element clicked on is not inside our menu reference we can close it, this includes the toggle button to open it
		if (!this.hiddenGenreFilter.contains(event.target)) {
			this.setState(
				{
					genreFilterOpen: false
				},
				() => {
					document.removeEventListener("click", this.closeGenreFilter);
				}
			);
		}
	};

	openYearFilter = () => {
		this.setState(
			{
				yearFilterOpen: true
			},
			() => {
				document.removeEventListener("click", this.closeYearFilter);
				document.addEventListener("click", this.closeYearFilter);
			}
		);
	};

	closeYearFilter = event => {
		if (!this.hiddenYearFilter.contains(event.target)) {
			this.setState(
				{
					yearFilterOpen: false
				},
				() => {
					document.removeEventListener("click", this.closeYearFilter);
				}
			);
		}
	};

	renderMediaItems = () => {
		if (this.state.filteredMedia.length) {
			return this.state.filteredMedia.map(m => {
				return (
					<li key={m.title} className="media-item">
						<img className="media-img" src={m.poster} height="480" width="320" />
						<div className="media-item-title">
							<span>{m.title}</span>
							<span> </span>
							<span>({m.year})</span>
						</div>
						<div className="media-item-genre">Genres: {m.genre.join(", ")}</div>
					</li>
				);
			});
		}

		return <React.Fragment>{"No Records found."}</React.Fragment>;
	};

	onMovieTypeChanged = e => {
		this.setState(
			{
				typeFilter: e.currentTarget.value
			},
			() => {
				this.applyFilters();
			}
		);
	};

	onBookTypeChanged = e => {
		this.setState(
			{
				typeFilter: e.currentTarget.value
			},
			() => {
				this.applyFilters();
			}
		);
	};

	clearFilters = () => {
		this.setState(
			{
				typeFilter: "",
				genre: [],
				years: [],
				searchVal: ""
			},
			() => {
				this.applyFilters();
			}
		);
	};

	search = e => {
		this.setState(
			{
				searchVal: e.currentTarget.value
			},
			() => {
				this.applyFilters();
			}
		);
	};

	genreSelected = e => {
		const v = e.currentTarget.value;
		const chk = e.currentTarget.checked;
		this.setState(
			prevState => {
				return {
					genre: chk ? prevState.genre.concat(v) : prevState.genre.filter(g => g !== v)
				};
			},
			() => {
				this.applyFilters();
			}
		);
	};

	yearSelected = e => {
		const v = e.currentTarget.value;
		const chk = e.currentTarget.checked;
		this.setState(
			prevState => {
				return {
					years: chk ? prevState.years.concat(v) : prevState.years.filter(y => y !== v)
				};
			},
			() => {
				this.applyFilters();
			}
		);
	};

	applyFilters = () => {
		let filteredMedia;

		if (
			this.state.genre.length ||
			this.state.years.length ||
			this.state.typeFilter.length ||
			this.state.searchVal.length
		) {
			filteredMedia = media.filter(m => {
				let matchedGenre = false;
				let matchedYear = false;
				let matchedType = false;
				let matchedSearchString = false;

				if (this.state.genre.length) {
					if ("genre" in m && m.genre.length && Array.isArray(m.genre)) {
						for (let i = 0, len = this.state.genre.length; i < len; i++) {
							if (m.genre.indexOf(this.state.genre[i]) !== -1) {
								matchedGenre = true;
								break;
							}
						}
					}
				}

				if (this.state.years.length) {
					if ("year" in m && m.year.length && this.state.years.indexOf(m.year) !== -1) {
						matchedYear = true;
					}
				}

				if (this.state.typeFilter.length) {
					if ("type" in m && m.type.length && m.type == this.state.typeFilter) {
						matchedType = true;
					}
				}

				if (this.state.searchVal.length) {
					matchedSearchString =
						m.title.toLowerCase().indexOf(this.state.searchVal.toLowerCase()) !== -1 ||
						m.year.toLowerCase().indexOf(this.state.searchVal.toLowerCase()) !== -1 ||
						m.genre.indexOf(this.state.searchVal.toLowerCase()) !== -1 ||
						m.type.toLowerCase().indexOf(this.state.searchVal.toLowerCase()) !== -1;
				}

				return ((this.state.genre.length > 0 && matchedGenre) || this.state.genre.length === 0) &&
					((this.state.years.length > 0 && matchedYear) || this.state.years.length === 0) &&
					((this.state.typeFilter.length > 0 && matchedType) || this.state.typeFilter.length === 0) &&
					((this.state.searchVal.length > 0 && matchedSearchString) || this.state.searchVal.length === 0)
					? m
					: null;
			});
		}

		this.setState({ filteredMedia: filteredMedia !== undefined ? filteredMedia : [...media] });
	};

	render() {
		return (
			<section className="filterableContent exercise-container">
				<div className="filterableContent-wrapper exercise-wrapper">
					<div>
						<div>
							<div className="filterableContent-headerRow">
								<div className="genre-container" onClick={this.openGenreFilter}>
									<span className="genre-link">Genre</span>
									{this.state.genreFilterOpen ? (
										<div>
											<ul
												className="hiddenFilter"
												ref={el => {
													this.hiddenGenreFilter = el;
												}}
											>
												{this.genres.map(i => (
													<li key={i.value}>
														<input
															name={`genre_${i.value}`}
															type="checkbox"
															checked={this.state.genre.indexOf(i.value) !== -1}
															value={i.value}
															onChange={this.genreSelected}
															className="genreFilterOption"
														/>
														{i.label}
													</li>
												))}
											</ul>
										</div>
									) : null}
								</div>
								<div className="year-container" onClick={this.openYearFilter}>
									<span>Year</span>
									{this.state.yearFilterOpen ? (
										<div className="year-filter-open">
											<ul
												className="hiddenFilter"
												ref={el => {
													this.hiddenYearFilter = el;
												}}
											>
												{this.years.map(i => (
													<li key={i}>
														<input
															name={`year_${i}`}
															type="checkbox"
															checked={this.state.years.indexOf(i) !== -1}
															value={i}
															onChange={this.yearSelected}
															className="yearFilterOption"
														/>
														{i}
													</li>
												))}
											</ul>
										</div>
									) : null}
								</div>
								<div className="search-container">
									<input
										className="search-input"
										type="text"
										value={this.state.searchVal}
										onChange={this.search}
										size="50"
									/>
								</div>
							</div>
							<div className="additionalFilterRow">
								<div className="additionalFilter">
									<input
										type="radio"
										name="typeFilter"
										checked={this.state.typeFilter === "movie"}
										onChange={this.onMovieTypeChanged}
										value="movie"
										className="additionalFilterInput"
									/>
									<label>Movies</label>
								</div>
								<div className="additionalFilter">
									<input
										type="radio"
										name="typeFilter"
										checked={this.state.typeFilter === "book"}
										onChange={this.onBookTypeChanged}
										value="book"
										className="additionalFilterInput"
									/>
									<label>Books</label>
								</div>
								<div className="clear-filters">
									<a onClick={this.clearFilters}>Clear filters</a>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div className="media-browser">
					<div className="media-wrapper">
						<div className="">
							<ul className="media-items">{this.renderMediaItems()}</ul>
						</div>
					</div>
				</div>
			</section>
		);
	}
}
