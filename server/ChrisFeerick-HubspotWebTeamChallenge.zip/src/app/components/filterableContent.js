import React, { Component } from "react";

import { media } from "../data/data.json";

export class FilterableContent extends Component {
	constructor(props) {
		super(props);
		this.state = {
			genreFilterOpen: false,
			filteredMedia: [...media],
			typeFilter: "",
			searchVal: "",
			genre: []
		};

		this.genres = [
			{ label: "Action", value: "action" },
			{ label: "Adventure", value: "adventure" },
			{ label: "Animation", value: "animation" },
			{ label: "Biography", value: "biography" },
			{ label: "Classics", value: "classics" },
			{ label: "Comedy", value: "comedy" },
			{ label: "Crime", value: "crime" },
			{ label: "Detective", value: "detective" },
			{ label: "Dragons", value: "dragons" },
			{ label: "Drama", value: "drama" },
			{ label: "Fantasy", value: "fantasy" },
			{ label: "Food & Drink", value: "food & drink" },
			{ label: "History", value: "history" },
			{ label: "Horror", value: "horror" },
			{ label: "Memoir", value: "memoir" },
			{ label: "Mystery", value: "mystery" },
			{ label: "Politics", value: "politics" },
			{ label: "Science Fiction", value: "sci-fi" },
			{ label: "Science", value: "science" },
			{ label: "Thriller", value: "thriller" },
			{ label: "War", value: "war" },
			{ label: "Western", value: "western" }
		];
	}

	genreClicked = () => {
		this.setState(prevState => ({
			genreFilterOpen: !prevState.genreFilterOpen
		}));
	};

	renderMediaItems = () => {
		return this.state.filteredMedia.map(m => {
			return (
				<li key={m.title} className="media-item">
					<img className="media-img" src={m.poster} height="480" width="320" />
					<div className="media-item-title">
						<span>{m.title}</span>
						<span> </span>
						<span>({m.year})</span>
					</div>
					<div className="media-item-genre">Genres: {m.genre.join(", ")}</div>
				</li>
			);
		});
	};

	filterBy = ({ key, value }) => {
		this.setState({
			filteredMedia: key.length ? media.filter(m => m[key].indexOf(value) !== -1) : [...media]
		});
	};

	onMovieTypeChanged = e => {
		this.setState({
			typeFilter: e.currentTarget.value
		});
		this.filterBy({ key: e.currentTarget.value.length ? "type" : "", value: "movie" });
	};

	onBookTypeChanged = e => {
		this.setState({
			typeFilter: e.currentTarget.value
		});
		this.filterBy({ key: e.currentTarget.value.length ? "type" : "", value: "book" });
	};

	clearFilters = () => {
		this.setState({
			typeFilter: "",
			genre: [],
			searchVal: ""
		});
		this.filterBy({ key: "", value: "" });
	};

	search = e => {
		const searchVal = e.currentTarget.value;
		let filteredMedia;

		if (searchVal.length) {
			filteredMedia = media.filter(m => {
				return (
					m.title.toLowerCase().indexOf(searchVal.toLowerCase()) !== -1 ||
					m.year.toLowerCase().indexOf(searchVal.toLowerCase()) !== -1 ||
					m.poster.toLowerCase().indexOf(searchVal.toLowerCase()) !== -1 ||
					m.genre.indexOf(searchVal.toLowerCase()) !== -1 ||
					m.type.toLowerCase().indexOf(searchVal.toLowerCase()) !== -1
				);
			});
		} else {
			filteredMedia = [...media];
		}
		this.setState({
			searchVal,
			filteredMedia
		});
	};

	genreSelected = e => {
		const v = e.currentTarget.value;
		const chk = e.currentTarget.checked;
		this.setState(
			prevState => {
				return {
					genre: chk ? prevState.genre.concat(v) : prevState.genre.filter(g => g !== v)
				};
			},
			() => {
				let filteredMedia = [];
				if (this.state.genre.length) {
					media.forEach(m => {
						if ("genre" in m && m.genre.length && Array.isArray(m.genre)) {
							this.state.genre.forEach(v => {
								if (m.genre.indexOf(v) !== -1) {
									filteredMedia.push(m);
								}
							});
						}
					});
					filteredMedia = media.filter(m => {
						let fnd = false;
						for (let i = 0, len = this.state.genre.length; i < len; i++) {
							if (m.genre.indexOf(this.state.genre[i]) !== -1) {
								fnd = true;
								break;
							}
						}
						return fnd ? m : null;
					});
				} else {
					filteredMedia = [...media];
				}

				this.setState({ filteredMedia });
			}
		);
	};

	render() {
		return (
			<section className="filterableContent exercise-container">
				<div className="filterableContent-wrapper exercise-wrapper">
					<div>
						<div>
							<div className="filterableContent-headerRow">
								<div className="genre-container" onClick={this.genreClicked}>
									<span className={`genre-link`}>Genre</span>
									<div
										className={`genre-filter genre-filter-${
											this.state.genreFilterOpen ? "open" : "closed"
										}`}
									>
										<ul className="hiddenGenreFilter">
											{this.genres.map(i => (
												<li key={i.value}>
													<input
														name={`genre_${i.value}`}
														type="checkbox"
														checked={this.state.genre.indexOf(i.value) !== -1}
														value={i.value}
														onChange={this.genreSelected}
														className="genreFilterOption"
													/>
													{i.label}
												</li>
											))}
										</ul>
									</div>
								</div>
								<div className="year-container">
									<span>Year</span>
									<div />
								</div>
								<div className="search-container">
									<input
										className="search-input"
										type="text"
										value={this.state.searchVal}
										onChange={this.search}
										size="50"
									/>
								</div>
							</div>
							<div className="additionalFilterRow">
								<div className="additionalFilter">
									<input
										type="radio"
										name="typeFilter"
										checked={this.state.typeFilter === "movie"}
										onChange={this.onMovieTypeChanged}
										value="movie"
										className="additionalFilterInput"
									/>
									<label>Movies</label>
								</div>
								<div className="additionalFilter">
									<input
										type="radio"
										name="typeFilter"
										checked={this.state.typeFilter === "book"}
										onChange={this.onBookTypeChanged}
										value="book"
										className="additionalFilterInput"
									/>
									<label>Books</label>
								</div>
								<div className="clear-filters">
									<a onClick={this.clearFilters}>Clear filters</a>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div className="media-browser">
					<div className="media-wrapper">
						<div className="">
							<ul className="media-items">{this.renderMediaItems()}</ul>
						</div>
					</div>
				</div>
			</section>
		);
	}
}
