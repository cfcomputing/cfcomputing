const media = require("./data.json").media;
const years = {};
media.forEach(m => {
	years[m.year] = m.year;
});

console.log(Object.keys(years).sort());
