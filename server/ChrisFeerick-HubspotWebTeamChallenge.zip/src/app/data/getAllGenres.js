const media = require("./data.json").media;
const genres = {};
media.forEach(m => {
	m.genre.forEach(g => {
		genres[g] = g;
	});
});

console.log(Object.keys(genres).sort());
