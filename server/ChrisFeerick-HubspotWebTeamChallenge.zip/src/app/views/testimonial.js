import React, { Component } from "react";

export class Testimonial extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		const { testimonial, author } = this.props;
		return (
			<div className="testimonial exercise-container">
				<div className="exercise-wrapper">
					<p className="testimonial-text">{testimonial}</p>
					<span className="testimonial-author">{author}</span>
				</div>
			</div>
		);
	}
}
