import React, { Component } from "react";

export class Quote extends Component {
	constructor(props) {
		super(props);

		this.state = {
			text: this.props.text
		};
	}

	fetchNewQuote = async () => {
		const req = await fetch("https://api.icndb.com/jokes/random");
		const json = await req.json();
		if (
			json &&
			"type" in json &&
			json.type === "success" &&
			"value" in json &&
			"joke" in json.value &&
			json.value.joke.length
		) {
			this.setState({
				text: json.value.joke
			});
		}
	};

	render() {
		const { text } = this.state;
		return (
			<section className="quote exercise-container">
				<div className="quote-wrapper exercise-wrapper">
					<p dangerouslySetInnerHTML={{ __html: text }} />
					<a onClick={this.fetchNewQuote}>{"Tell Me More"}</a>
				</div>
			</section>
		);
	}
}
