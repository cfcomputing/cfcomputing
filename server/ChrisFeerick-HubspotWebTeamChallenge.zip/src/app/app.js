import React from "react";

// eslint-disable-next-line no-unused-vars
import App from "./styles/app.scss";

import { Testimonial } from "./views/testimonial";
import { Quote } from "./views/quote";
import { FilterableContent } from "./components/filterableContent";

export class AppComponent extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			testimonial: {
				text:
					"Poloroid bushwick microdosing tatooed. Cornhole single-origin coffee bicycle rights lumbersexual, pour over intelligentsia bahn mi ethical selfies schlizt raw denim 90's leggings. Art party venmo chia, fab lumbersexual mustache actually tilde disrupt kinfolk cray health goth +1.",
				author: "Indiana Jones, Archeologist"
			},
			cta: {
				text:
					"Ability decrease antimagic balance domain base save bonus caster level check class skill cowering effective hit point increase eladrin subtype energy drained fear aura fear cone fear effect fraction frightful presence improved evasion level massive damage melee attach mentalism domain racial hit die retribution domain spell threat range touch spell turn undead. Character coupe de grace destruction domain fate domain goblinoid subtype lava effects monk mundane native subtype paralysis pattern subschool regneration. Animal type aquatic subtype change shape competence bonus dispel dispel turning drow domain gnome domain initiative count luck bonus overlap renewal domain scry spell descriptor spell resistance suprise total concealmeant unarmed attack."
			}
		};
	}

	render() {
		return (
			<React.Fragment>
				{/* 
                    <% include ../partials/_testimonial %>

                    <% include ../partials/_cta %>

                    <% include ../partials/_filterable-content %> 
                */}

				<Testimonial testimonial={this.state.testimonial.text} author={this.state.testimonial.author} />
				<Quote text={this.state.cta.text} />
				<FilterableContent />
			</React.Fragment>
		);
	}
}
