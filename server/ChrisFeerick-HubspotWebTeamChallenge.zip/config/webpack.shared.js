const paths = require("./paths");

module.exports = {
	entry: {
		app: [paths.indexfile]
	},
	output: {
		filename: "main.js",
		path: paths.dist
	},
	resolve: {
		alias: {
			app: paths.app
		}
	},
	module: {
		rules: [
			{
				loader: "eslint-loader",
				test: /\.(js|jsx)$/,
				enforce: "pre",
				exclude: /node_modules/,
				include: paths.src
			},
			{
				loader: "babel-loader",
				test: /\.(js|jsx)$/,
				exclude: /node_modules/,
				include: paths.src
			},
			{
				test: /\.scss$/,
				use: [
					"style-loader", // creates style nodes from JS strings
					"css-loader", // translates CSS into CommonJS
					"sass-loader" // compiles Sass to CSS, using Node Sass by default
				],
				exclude: /node_modules/,
				include: paths.src
			}
		]
	}
};
