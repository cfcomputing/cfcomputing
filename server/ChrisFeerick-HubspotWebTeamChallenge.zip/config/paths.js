const fs = require("fs");
const path = require("path");
const appDirectoryResolved = fs.realpathSync(process.cwd());

module.exports = {
	build: path.resolve(appDirectoryResolved, "build/"),
	src: path.resolve(appDirectoryResolved, "src/"),
	indexfile: path.resolve(appDirectoryResolved, "src/index.js"),
	publicsrc: path.resolve(appDirectoryResolved, "public/"),
	htmlfile: path.resolve(appDirectoryResolved, "public/index.html"),
	app: path.resolve(appDirectoryResolved, "src/app/")
};
