# Submission Notes

These notes will be read by HubSpot developers. Drop us a line!

## Given more time, what would you have done differently?

I would clean up the sass and put it into a few different files. I would add tests for everything. I would have spent more time on the layout and ensuring everything works properly on all devices. I would have spent more time making sure to come up with what would be the proper breakpoints and proper spacing for all the elements. I have typically offloaded much of this work to frameworks and/or other members of the team, it has been a while since I spent time matching on pixel based mockups. I was not able to get to the Year filter. I was also not able to implement the proper dropdown menu for the Genre. I would spend more time building the proper dropdown that closes on clicks outside of it and I would keep it open so they could choose multiple options.

## Is there anything else you'd like to let us know?

The day after I spoke with Dmitry I had to go to Austrailia for work and during my travels my laptop screen was damaged and I was not able to work on this until Tuesday evening after getting back home and while I spent a good couple hours on it I know if I could spent more time I would be able to match the mockups closer and write some cleaner code.
